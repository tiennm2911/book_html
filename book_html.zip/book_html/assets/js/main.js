$(document).ready(function () {
    $('.cursor-pointer').click(function () {
        var parent = $(this).parent();
        parent.children('.items').toggleClass('hidden');
        $(this).find('button.icon-arrow').toggleClass('rotate-180');
    });
});
